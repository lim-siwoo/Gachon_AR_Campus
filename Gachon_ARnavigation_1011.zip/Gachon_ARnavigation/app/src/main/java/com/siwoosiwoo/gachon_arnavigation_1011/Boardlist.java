package com.siwoosiwoo.gachon_arnavigation_1011;

public class Boardlist {
    String title;
    String content;

    Boardlist(){}

    Boardlist(String title, String content){
        this.title=title;
        this.content=content;
    }
    public String getTitle(){return title;}
    public String getcontent(){return content;}

}
